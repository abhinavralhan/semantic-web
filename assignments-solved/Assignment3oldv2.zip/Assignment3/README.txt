Semantic Web
Assignment 3


                       Johannes Härtel                 Iryna Dubrovska


Institute of Web Science and Technologies
Department of Computer Science
University of Koblenz-Landau



Team Members : 

Abhinav Ralhan   221202684   abhinavr8@uni-koblenz.de
Bhargavi Kannan  221202311   bhargavikannan@uni-koblenz.de
Varnana Vijay    221202682   varnanavijay@uni-koblenz.de


Date: 27th May 2022

This submission contains 2 folders with answers respective to the given questions in Ass3.